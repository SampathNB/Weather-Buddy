import clsx from "clsx";
import {Container} from "../ElementsComponents";

interface HeaderTypes {
  className?: string;
  onHomePage?: boolean;
}

export const Header = ({className, onHomePage = false}: HeaderTypes) => {
  const barClassName = "block bg-black w-8 h-0.5";
  return (
    <>
      <header className={"py-3 border border-gray-200"}>
        <Container>
          <div className={clsx("flex items-center justify-between", className)}>
            <a href="/" className="text-2xl text-black font-bold">
              SAMPATH BINGI
            </a>
            <div className="px-4">
              <button className="p-2 px-5 rounded-3xl border border-black flex flex-col gap-1">
                <span className={barClassName}></span>
                <span className={barClassName}></span>
                <span className={barClassName}></span>
              </button>
            </div>
          </div>
        </Container>
      </header>
    </>
  );
};
